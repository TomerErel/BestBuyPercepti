

users = [
    {"username": "tomer260996@gmail.com", "password": "NQ:p.8_daUph:d4"},
    {"username": "checking@percepti.co", "password": "checking@percepti.co"}
]

user_agent_="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
